<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'PgJXiwMSkRUQAVawVG6aA');
define('CONSUMER_SECRET', 'qeS76BuzfM9PC5mljU9SdGc1cTkH08lFawD7sqdc2Us');

define('TOKEN', '2205625172-wR7qhNaRUEmSUQ9xMctynuH0K69KHzxiF5HZbe2');
define('SECRET', 'DPsD4zzCzxq1bucO1w1y3I8pm44tmn21PnWAUtCelZR3l');

define('OAUTH_CALLBACK', 'http://localhost/nearme/twitteroauth/callback.php');

?>